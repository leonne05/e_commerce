 <div class="bg-info p-3 text-center">
  <p>All rights reserved @- Designed by Besbi-2023</p>
  </div>
