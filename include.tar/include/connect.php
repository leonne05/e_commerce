<?php
   $con=mysqli_connect('localhost', 'root', '', 'Mystore');
   if(!$con){
       die(mysql_error($con));
   }
?>